import { defineConfig } from 'vite';
import { viteStaticCopy } from 'vite-plugin-static-copy'; // ✅ 正确导入插件

export default defineConfig({
  base: './', // ✅ 重要！确保相对路径，防止服务器路径错误
  plugins: [
    viteStaticCopy({
      targets: [
        { src: 'public/models/*', dest: 'models' }, // ✅ 修正 models 路径
        { src: 'public/hdr/*', dest: 'hdr' }       // ✅ 修正 hdr 路径
      ]
    })
  ],
});