import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RGBELoader } from 'three/examples/jsm/loaders/RGBELoader.js';
import { GUI } from 'lil-gui';  // 替换为 lil-gui
import Stats from 'stats.js';
// 解压缩模块
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader.js'; // 支持 Draco 解压缩
import { MeshoptDecoder } from 'three/examples/jsm/libs/meshopt_decoder.module.js'; // 支持 Meshopt 解压缩
// 后处理模块SSAO和泛光
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { SSAOPass } from 'three/examples/jsm/postprocessing/SSAOPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
// 引入 SSRPass 模块
import { SSRPass } from 'three/examples/jsm/postprocessing/SSRPass.js';

// 场景
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000000); // 背景色

// 相机
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(-10, 10, 10); // 相机位置
camera.lookAt(0, 0, 0); // 相机指向场景中心

// 渲染器
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(window.devicePixelRatio); // 添加像素比设置
renderer.shadowMap.enabled = true; // 启用阴影
renderer.shadowMap.type = THREE.PCFSoftShadowMap; // 阴影类型
renderer.outputEncoding = THREE.sRGBEncoding; // 设置输出编码
renderer.toneMapping = THREE.ACESFilmicToneMapping; // 设置色调映射
renderer.toneMappingExposure = 1.0; // 设置曝光度
document.body.appendChild(renderer.domElement);

// 雾气
let fogColor = new THREE.Color(0xffffff); // 雾气颜色
let fogDensity = 0.0009; // 雾气浓度

// HDR贴图
const hdrPath = 'hdr/skybox.hdr';
const rgbeLoader = new RGBELoader();
const loadHDRBackground = (enableBackground) => {
  rgbeLoader.load(hdrPath, (texture) => {
    texture.mapping = THREE.EquirectangularReflectionMapping; // 改为反射映射
    texture.encoding = THREE.sRGBEncoding; // 确保编码正确
    scene.environment = texture;
    scene.background = enableBackground ? texture : new THREE.Color(params.backgroundColor);
  }, undefined, (error) => {
    console.error('HDR加载失败:', error);
    scene.background = new THREE.Color(params.backgroundColor); // 恢复默认背景
    scene.environment = null;
  });
};

// 地面
const groundGeometry = new THREE.CircleGeometry(30, 64);
const groundMaterial = new THREE.MeshStandardMaterial({ 
    color: 0xeeeeee, 
    side: THREE.FrontSide // 渲染正面
});
const ground = new THREE.Mesh(groundGeometry, groundMaterial);
ground.rotation.x = -Math.PI / 2; // 正面朝上
ground.receiveShadow = true; // 接收阴影
ground.visible = false; // 默认隐藏地面
scene.add(ground);

// 声明动画混合器变量
let mixer;

// 配置 GLTFLoader
const loader = new GLTFLoader();

// Meshopt 解压缩
loader.setMeshoptDecoder(MeshoptDecoder);

// Draco 解压缩
const dracoLoader = new DRACOLoader();
dracoLoader.setDecoderPath('draco/'); // Draco 解码库的实际路径
loader.setDRACOLoader(dracoLoader);

// 加载模型和动画
loader.load('models/model.glb', (gltf) => {
  const model = gltf.scene;
  
  model.traverse((child) => {
    if (child.isMesh) {
      child.castShadow = true; // 所有模型默认投射阴影

      // 仅名字中包含 "floor" 的模型接收阴影
      if (child.name.includes('floor')) {
        child.receiveShadow = true;
      } else {
        child.receiveShadow = false; // 防止其他模型误接收阴影
      }
    }
  });
  scene.add(model);
  handleAnimations(gltf); // 调用动画处理函数
}, undefined, (error) => {
  console.error('模型加载失败:', error);
});

// 动画处理函数
function handleAnimations(gltf) {
  if (gltf.animations && gltf.animations.length > 0) {
    mixer = new THREE.AnimationMixer(gltf.scene);
    gltf.animations.forEach((clip) => {
      mixer.clipAction(clip).play();
    });
  }
}

// 环境光
const ambientLight = new THREE.AmbientLight(0x404040, 0);
scene.add(ambientLight);

// 点光源一
const pointLight1 = new THREE.PointLight(0xffffff, 0, 100, 2);
pointLight1.position.set(0, 3, 1); // 设置光源位置
pointLight1.castShadow = true; // 启用阴影
scene.add(pointLight1);
const lightHelper1 = new THREE.Mesh(
  new THREE.SphereGeometry(0.05), // 小球尺寸
  new THREE.MeshBasicMaterial({ color: 0xcccccc }) // 球体颜色
);
lightHelper1.position.copy(pointLight1.position);
scene.add(lightHelper1);
lightHelper1.visible = false; // 默认隐藏小球

// 点光源二
const pointLight2 = new THREE.PointLight(0xffffff, 0, 100, 2);
pointLight2.position.set(0, 2, -1); // 设置光源位置
pointLight2.castShadow = true; // 启用阴影
scene.add(pointLight2);
const lightHelper2 = new THREE.Mesh(
  new THREE.SphereGeometry(0.05), // 小球尺寸
  new THREE.MeshBasicMaterial({ color: 0xcccccc }) // 球体颜色
);
lightHelper2.position.copy(pointLight2.position);
scene.add(lightHelper2);
lightHelper2.visible = false; // 默认隐藏小球

// 平行光
const directionalLight = new THREE.DirectionalLight(0xffffff, 2.7);
directionalLight.position.set(-10, 10, 10); // 调整光源方向
directionalLight.target.position.set(0, 0, 0); // 指向地面中心
directionalLight.castShadow = true; // 启用阴影
scene.add(directionalLight.target);
scene.add(directionalLight);
const dirLightHelper = new THREE.ArrowHelper(
  directionalLight.target.position.clone().sub(directionalLight.position).normalize(),
  directionalLight.position,
  1.5, // 箭头长度
  0xcccccc // 箭头颜色
);
scene.add(dirLightHelper);
dirLightHelper.visible = false; // 默认隐藏箭头

// 聚光灯
const spotLight = new THREE.SpotLight(0xffffff, 0);
spotLight.position.set(-2, 4, 2); // 调整光源位置
spotLight.castShadow = true; // 启用阴影
spotLight.penumbra = 0.6; // 边缘柔化程度
const targetObj = new THREE.Object3D();
targetObj.position.set(0, 0, 0);
scene.add(targetObj);
spotLight.target = targetObj;
scene.add(spotLight);
scene.add(spotLight.target);
const spotLightHelper = new THREE.ArrowHelper(
  targetObj.position.clone().sub(spotLight.position).normalize(),
  spotLight.position,
  1.5, // 箭头长度
  0xcccccc // 箭头颜色
);
scene.add(spotLightHelper);
spotLightHelper.visible = false; // 默认隐藏箭头

// 统一设置阴影参数
scene.traverse((object) => {
  if (object.isLight && object.castShadow) {
    object.shadow.mapSize.width = 1024; // 阴影分辨率
    object.shadow.mapSize.height = 1024;
    object.shadow.bias = -0.001; // 阴影偏移
    object.shadow.radius = 7; // 柔化半径，仅对点光源和聚光灯有效
  }
});

// 控制器
let controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true; // 开启阻尼
controls.dampingFactor = 0.25; // 阻尼强度
controls.screenSpacePanning = false;
controls.mouseButtons = {
  LEFT: THREE.MOUSE.ROTATE,
  MIDDLE: THREE.MOUSE.DOLLY,
  RIGHT: THREE.MOUSE.PAN,
};
controls.minPolarAngle = 0; // 限制控制器俯视角度
controls.maxPolarAngle = Math.PI / 2.1; // 限制控制器平视角度且不要小于2

// 创建时钟
const clock = new THREE.Clock(); // 定义时钟

// 显示FPS面板
const stats = new Stats();
stats.showPanel(0);
document.body.appendChild(stats.dom);

// 后处理
const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene, camera));

// SSAO环境光遮蔽
const ssaoPass = new SSAOPass(scene, camera, window.innerWidth, window.innerHeight);
ssaoPass.kernelRadius = 16; // 环境光遮蔽的范围
ssaoPass.minDistance = 0.005; // 最小距离
ssaoPass.maxDistance = 0.1; // 最大距离
ssaoPass.enabled = false; // 默认关闭SSAO
composer.addPass(ssaoPass);

// 泛光
const bloomPass = new UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), 0.1, 0.4, 0.85);
composer.addPass(bloomPass);

// SSR 屏幕空间反射
let ssrPass = null; // 初始状态无 SSR
const ssrParams = {
  enabled: false,         // 默认关闭SSR
  maxDistance: 1.5,       // SSR反射最大距离
  thickness: 0.5,         // SSR厚度
  reflectivity: 0.5,      // SSR反射强度（降低以减少性能消耗）
  quality: 0.3,           // SSR反射质量（降低以减少性能消耗）
  resolution: 64,         // SSR分辨率（降低以减少性能消耗）
  blur: true,             // 是否开启模糊
  kernelSize: 2,          // 模糊精度（降低以减少性能消耗）
  iterations: 1,          // 迭代次数（降低以减少性能消耗）
  blurAmount: 0.3,        // 模糊强度（降低以减少性能消耗）
};

// 动画循环函数
function animate() {
  stats.begin();
  requestAnimationFrame(animate);
  const delta = clock.getDelta();
  if (mixer) mixer.update(delta);
  controls.update();
  composer.render();
  stats.end();
}

// 响应式调整渲染器大小
window.addEventListener('resize', onWindowResize, false);
function onWindowResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  composer.setSize(window.innerWidth, window.innerHeight);
  ssaoPass.setSize(window.innerWidth, window.innerHeight);
  if (ssrPass) {
    ssrPass.setSize(window.innerWidth, window.innerHeight);
  }
  bloomPass.setSize(window.innerWidth, window.innerHeight);
}

// GUI 控制面板默认参数
const params = {
  dampingFactor: controls.dampingFactor, // 阻尼
  statsVisible: true, // FPS参数
  hdrEnabled: true, // HDR
  hdrBackgroundEnabled: true, // 启用 HDR 背景
  hdrExposure: renderer.toneMappingExposure, // HDR曝光度
  angleLimitEnabled: true, // 角度限制
  backgroundColor: scene.background.getHex(), // 背景色
  ambientLightIntensity: ambientLight.intensity, // 环境光强度
  ambientLightColor: ambientLight.color.getHex(), // 环境光颜色
  pointLight1Intensity: pointLight1.intensity, // 点光一强度
  pointLight1Color: pointLight1.color.getHex(), // 点光一颜色
  pointLight1Decay: pointLight1.decay, // 点光1衰减
  pointLight2Intensity: pointLight2.intensity, // 点光二强度
  pointLight2Color: pointLight2.color.getHex(), // 点光2颜色
  pointLight2Decay: pointLight2.decay, // 点光2衰减
  directionalLightIntensity: directionalLight.intensity, // 平行光强度
  directionalLightColor: directionalLight.color.getHex(), // 平行光颜色
  spotLightIntensity: spotLight.intensity, // 聚光强度
  spotLightColor: spotLight.color.getHex(), // 聚光颜色
  spotLightPenumbra: spotLight.penumbra, // 聚光灯边缘柔化
  pointLight1Visible: lightHelper1.visible, // 默认关闭点光一助手
  pointLight2Visible: lightHelper2.visible, // 默认关闭点光二源助手
  directionalLightVisible: dirLightHelper.visible, // 默认关闭平行光助手
  spotLightVisible: spotLightHelper.visible, // 默认关闭聚光助手
  pointLight1Position: pointLight1.position, // 点光一位置
  pointLight2Position: pointLight2.position, // 点光二位置
  directionalLightPosition: directionalLight.position, // 平行光位置
  spotLightPosition: spotLight.position, // 聚光灯位置
  directionalLightRotation: directionalLight.rotation, // 平行光旋转
  spotLightRotation: spotLight.rotation, // 聚光灯旋转
  groundVisible: false, // 地面
  groundColor: groundMaterial.color.getHex(), // 地面颜色
  shadowEnabled: true,  // 启用阴影
  shadowBias: pointLight1.shadow.bias,  // 阴影偏移
  shadowRadius: pointLight1.shadow.radius, // 阴影半径
  shadowMapSizeX: pointLight1.shadow.mapSize.width,  // 阴影分辨率宽度
  shadowMapSizeY: pointLight1.shadow.mapSize.height,  // 阴影分辨率高度
  ssaoEnabled: ssaoPass.enabled, // 启用SSAO
  ssaoKernelRadius: ssaoPass.kernelRadius, // 内核半径
  ssaoMinDistance: ssaoPass.minDistance, // 最小距离
  ssaoMaxDistance: ssaoPass.maxDistance, // 最大距离
  bloomStrength: bloomPass.strength, // 泛光强度
  bloomThreshold: bloomPass.threshold, // 泛光阈值
  bloomRadius: bloomPass.radius, // 泛光半径
  ssrEnabled: ssrParams.enabled, // 启用SSR
  ssrDistance: ssrParams.maxDistance, // SSR距离
  ssrThickness: ssrParams.thickness, // SSR厚度
  ssrReflectivity: ssrParams.reflectivity, // SSR反射强度
  ssrQuality: ssrParams.quality, // SSR质量
  ssrResolution: ssrParams.resolution, // SSR分辨率
  ssrBlur: ssrParams.blur, // SSR模糊
  ssrKernelSize: ssrParams.kernelSize, // SSR模糊精度
  ssrIterations: ssrParams.iterations, // SSR迭代次数
  ssrBlurAmount: ssrParams.blurAmount, // SSR模糊强度
  fogEnabled: true,  // 是否启用雾气
  fogColor: fogColor.getHex(), // 雾气颜色
  fogDensity: fogDensity   // 雾气浓度
};

// GUI 控制面板
const gui = new GUI();

// H键隐藏面板
let isHidden = false; // 跟踪面板是否已隐藏
document.addEventListener('keydown', (event) => {
  if (event.key === 'h' || event.key === 'H') {
    isHidden = !isHidden; // 切换状态

    if (isHidden) {
      gui.domElement.style.display = 'none'; // 隐藏面板
    } else {
      gui.domElement.style.display = 'block'; // 显示面板
    }
  }
});

// 阻尼控制
gui.add(params, 'dampingFactor', 0.05, 0.3).name('阻尼强度').onChange((value) => {
  controls.dampingFactor = value;
});

// HDR 控制
if (params.hdrEnabled) {
  loadHDRBackground(params.hdrBackgroundEnabled);
} else {
  scene.background = new THREE.Color(params.backgroundColor);
  scene.environment = null;
}
gui.add(params, 'hdrEnabled').name('HDR').onChange((enabled) => {
  if (enabled) {
    loadHDRBackground(params.hdrBackgroundEnabled);
  } else {
    scene.background = new THREE.Color(params.backgroundColor); // 隐藏 HDR 背景
    scene.environment = null;
  }
});
gui.add(params, 'hdrBackgroundEnabled').name('HDR 背景').onChange((enabled) => {
  if (params.hdrEnabled) {
    loadHDRBackground(enabled); // 只有 HDR 启用时才能显示或隐藏背景
  } else {
    console.warn('请先启用 HDR 后再控制背景显示。');
    params.hdrBackgroundEnabled = false;
  }
});

// 添加 HDR 曝光度控制
gui.add(params, 'hdrExposure', 0, 2).name('HDR曝光度').onChange((value) => {
  renderer.toneMappingExposure = value;
});

// 地面控制
gui.add(params, 'groundVisible').name('显示地面').onChange((visible) => {
  ground.visible = visible;  // 设置地面是否可见
});
gui.addColor(params, 'groundColor').name('地面颜色').onChange((color) => {
  ground.material.color.set(color);  // 更新地面颜色
});

// 背景色控制
gui.addColor(params, 'backgroundColor').name('背景颜色').onChange((color) => {
  if (!params.hdrEnabled || !params.hdrBackgroundEnabled) {
    scene.background.set(color);
    renderer.setClearColor(color, 1);
  }
});

// 光源强度和颜色控制
gui.add(params, 'ambientLightIntensity', 0, 5).name('环境光强度').onChange((value) => {
  ambientLight.intensity = value;
});
gui.addColor(params, 'ambientLightColor').name('环境光颜色').onChange((color) => {
  ambientLight.color.set(color);
});
gui.add(params, 'pointLight1Intensity', 0, 100).name('点光1强度').onChange((value) => {
  pointLight1.intensity = value;
});
gui.add(pointLight1, 'decay', 0, 5).name('点光1衰减').onChange((value) => {
  pointLight1.decay = value;
});
gui.addColor(params, 'pointLight1Color').name('点光1颜色').onChange((color) => {
  pointLight1.color.set(color);
});
gui.add(params, 'pointLight2Intensity', 0, 100).name('点光2强度').onChange((value) => {
  pointLight2.intensity = value;
});
gui.add(pointLight2, 'decay', 0, 5).name('点光2衰减因子').onChange((value) => {
  pointLight2.decay = value;
});
gui.addColor(params, 'pointLight2Color').name('点光2颜色').onChange((color) => {
  pointLight2.color.set(color);
});
gui.add(params, 'directionalLightIntensity', 0, 10).name('平行光强度').onChange((value) => {
  directionalLight.intensity = value;
});
gui.addColor(params, 'directionalLightColor').name('平行光颜色').onChange((color) => {
  directionalLight.color.set(color);
});
gui.add(params, 'spotLightIntensity', 0, 200).name('聚光强度').onChange((value) => {
  spotLight.intensity = value;
});
gui.add(params, 'spotLightPenumbra', 0, 1).name('聚光柔化边缘').onChange((value) => {
  spotLight.penumbra = value;
});
gui.addColor(params, 'spotLightColor').name('聚光颜色').onChange((color) => {
  spotLight.color.set(color);
});

// 光源助手显示与否控制
gui.add(params, 'pointLight1Visible').name('点光1助手').onChange((visible) => {
  lightHelper1.visible = visible;
});
gui.add(params, 'pointLight2Visible').name('点光2助手').onChange((visible) => {
  lightHelper2.visible = visible;
});
gui.add(params, 'directionalLightVisible').name('平行光助手').onChange((visible) => {
  dirLightHelper.visible = visible;
});
gui.add(params, 'spotLightVisible').name('聚光助手').onChange((visible) => {
  spotLightHelper.visible = visible;
});

// 点光位置控制
gui.add(params.pointLight1Position, 'x', -10, 10).name('点光1 X').onChange(() => {
  pointLight1.position.set(params.pointLight1Position.x, params.pointLight1Position.y, params.pointLight1Position.z);
  lightHelper1.position.copy(pointLight1.position);
});
gui.add(params.pointLight1Position, 'y', -10, 10).name('点光1 Y').onChange(() => {
  pointLight1.position.set(params.pointLight1Position.x, params.pointLight1Position.y, params.pointLight1Position.z);
  lightHelper1.position.copy(pointLight1.position);
});
gui.add(params.pointLight1Position, 'z', -10, 10).name('点光1 Z').onChange(() => {
  pointLight1.position.set(params.pointLight1Position.x, params.pointLight1Position.y, params.pointLight1Position.z);
  lightHelper1.position.copy(pointLight1.position);
});
gui.add(params.pointLight2Position, 'x', -10, 10).name('点光2 X').onChange(() => {
  pointLight2.position.set(params.pointLight2Position.x, params.pointLight2Position.y, params.pointLight2Position.z);
  lightHelper2.position.copy(pointLight2.position);
});
gui.add(params.pointLight2Position, 'y', -10, 10).name('点光2 Y').onChange(() => {
  pointLight2.position.set(params.pointLight2Position.x, params.pointLight2Position.y, params.pointLight2Position.z);
  lightHelper2.position.copy(pointLight2.position);
});
gui.add(params.pointLight2Position, 'z', -10, 10).name('点光2 Z').onChange(() => {
  pointLight2.position.set(params.pointLight2Position.x, params.pointLight2Position.y, params.pointLight2Position.z);
  lightHelper2.position.copy(pointLight2.position);
});

// 平行光位置控制
gui.add(params.directionalLightPosition, 'x', -10, 10).name('平行光 X').onChange(() => {
  directionalLight.position.set(params.directionalLightPosition.x, params.directionalLightPosition.y, params.directionalLightPosition.z);
  dirLightHelper.position.copy(directionalLight.position);
  dirLightHelper.setDirection(directionalLight.target.position.clone().sub(directionalLight.position).normalize());
});
gui.add(params.directionalLightPosition, 'y', -10, 10).name('平行光 Y').onChange(() => {
  directionalLight.position.set(params.directionalLightPosition.x, params.directionalLightPosition.y, params.directionalLightPosition.z);
  dirLightHelper.position.copy(directionalLight.position);
  dirLightHelper.setDirection(directionalLight.target.position.clone().sub(directionalLight.position).normalize());
});
gui.add(params.directionalLightPosition, 'z', -10, 10).name('平行光 Z').onChange(() => {
  directionalLight.position.set(params.directionalLightPosition.x, params.directionalLightPosition.y, params.directionalLightPosition.z);
  dirLightHelper.position.copy(directionalLight.position);
  dirLightHelper.setDirection(directionalLight.target.position.clone().sub(directionalLight.position).normalize());
});

// 平行光旋转控制
gui.add(params.directionalLightRotation, 'x', -Math.PI, Math.PI).name('平行光旋转 X').onChange(() => {
  dirLightHelper.rotation.set(params.directionalLightRotation.x, params.directionalLightRotation.y, params.directionalLightRotation.z);
});
gui.add(params.directionalLightRotation, 'y', -Math.PI, Math.PI).name('平行光旋转 Y').onChange(() => {
  dirLightHelper.rotation.set(params.directionalLightRotation.x, params.directionalLightRotation.y, params.directionalLightRotation.z);
});
gui.add(params.directionalLightRotation, 'z', -Math.PI, Math.PI).name('平行光旋转 Z').onChange(() => {
  dirLightHelper.rotation.set(params.directionalLightRotation.x, params.directionalLightRotation.y, params.directionalLightRotation.z);
});

// 聚光灯位置控制
gui.add(params.spotLightPosition, 'x', -10, 10).name('聚光 X').onChange(() => {
  spotLight.position.set(params.spotLightPosition.x, params.spotLightPosition.y, params.spotLightPosition.z);
  spotLightHelper.position.copy(spotLight.position);
});
gui.add(params.spotLightPosition, 'y', -10, 10).name('聚光 Y').onChange(() => {
  spotLight.position.set(params.spotLightPosition.x, params.spotLightPosition.y, params.spotLightPosition.z);
  spotLightHelper.position.copy(spotLight.position);
});
gui.add(params.spotLightPosition, 'z', -10, 10).name('聚光 Z').onChange(() => {
  spotLight.position.set(params.spotLightPosition.x, params.spotLightPosition.y, params.spotLightPosition.z);
  spotLightHelper.position.copy(spotLight.position);
});

// 聚光灯旋转控制
gui.add(params.spotLightRotation, 'x', -Math.PI, Math.PI).name('聚光旋转 X').onChange(() => {
  spotLightHelper.rotation.set(params.spotLightRotation.x, params.spotLightRotation.y, params.spotLightRotation.z);
});
gui.add(params.spotLightRotation, 'y', -Math.PI, Math.PI).name('聚光旋转 Y').onChange(() => {
  spotLightHelper.rotation.set(params.spotLightRotation.x, params.spotLightRotation.y, params.spotLightRotation.z);
});
gui.add(params.spotLightRotation, 'z', -Math.PI, Math.PI).name('聚光旋转 Z').onChange(() => {
  spotLightHelper.rotation.set(params.spotLightRotation.x, params.spotLightRotation.y, params.spotLightRotation.z);
});

// SSAO 控制
gui.add(params, 'ssaoEnabled').name('启用SSAO').onChange((enabled) => {
  ssaoPass.enabled = enabled;
});
gui.add(params, 'ssaoKernelRadius', 1, 32).name('SSAO内核半径').onChange((value) => {
  ssaoPass.kernelRadius = value;
});
gui.add(params, 'ssaoMinDistance', 0.001, 0.1).name('SSAO最小距离').onChange((value) => {
  ssaoPass.minDistance = value;
});
gui.add(params, 'ssaoMaxDistance', 0.01, 1).name('SSAO最大距离').onChange((value) => {
  ssaoPass.maxDistance = value;
});

// 泛光控制
gui.add(params, 'bloomStrength', 0, 1).name('泛光强度').onChange((value) => {
  bloomPass.strength = value;
});
gui.add(params, 'bloomThreshold', 0, 1).name('泛光阈值').onChange((value) => {
  bloomPass.threshold = value;
});
gui.add(params, 'bloomRadius', 0, 1).name('泛光半径').onChange((value) => {
  bloomPass.radius = value;
});

// 阴影控制
gui.add(params, 'shadowEnabled').name('启用阴影').onChange((enabled) => {
  scene.traverse((object) => {
    if (object.isLight) {
      object.castShadow = enabled;

      if (object.shadow) {
        if (enabled) {
          // 启用阴影时，确保光源的阴影参数正确
          object.shadow.mapSize.width = params.shadowMapSizeX;
          object.shadow.mapSize.height = params.shadowMapSizeY;
          object.shadow.bias = params.shadowBias;
          object.shadow.radius = params.shadowRadius;
          object.shadow.needsUpdate = true; // 强制更新阴影贴图
        } else {
          // 关闭阴影时，重置阴影参数以避免残留问题
          object.shadow.mapSize.width = 1024; // 默认值
          object.shadow.mapSize.height = 1024; // 默认值
          object.shadow.bias = -0.001; // 默认值
          object.shadow.radius = 7; // 默认值
          object.shadow.needsUpdate = true; // 强制更新阴影贴图
        }
      }
    }
  });
});
gui.add(params, 'shadowBias', -0.01, 0.01).name('阴影偏移').onChange((value) => {
  scene.traverse((object) => {
    if (object.isLight && object.castShadow && object.shadow) {
      object.shadow.bias = value;
    }
  });
});
gui.add(params, 'shadowRadius', 0, 20).name('阴影柔化半径').onChange((value) => {
  scene.traverse((object) => {
    if (object.isLight && object.castShadow && object.shadow) {
      object.shadow.radius = value;
    }
  });
});
gui.add(params, 'shadowMapSizeX', 512, 2048).name('阴影分辨率 X').onChange((value) => {
  scene.traverse((object) => {
    if (object.isLight && object.castShadow && object.shadow) {
      object.shadow.mapSize.width = value;
      object.shadow.needsUpdate = true; // 强制更新阴影贴图
    }
  });
});
gui.add(params, 'shadowMapSizeY', 512, 2048).name('阴影分辨率 Y').onChange((value) => {
  scene.traverse((object) => {
    if (object.isLight && object.castShadow && object.shadow) {
      object.shadow.mapSize.height = value;
      object.shadow.needsUpdate = true; // 强制更新阴影贴图
    }
  });
});

// FPS 面板控制
gui.add(params, 'statsVisible').name('FPS面板').onChange((visible) => {
  stats.dom.style.display = visible ? '' : 'none';
});

// 角度控制
gui.add(params, 'angleLimitEnabled').name('角度限制').onChange((enabled) => {
  if (enabled) {
    controls.minPolarAngle = 0; 
    controls.maxPolarAngle = Math.PI / 2.5; 
  } else {
    controls.minPolarAngle = 0; 
    controls.maxPolarAngle = Math.PI;
  }
});

// SSR 控制
gui.add(params, 'ssrEnabled').name('启用SSR').onChange((enabled) => {
  ssrParams.enabled = enabled;
  if (enabled) {
    if (!ssrPass) {
      ssrPass = new SSRPass({
        renderer,
        scene,
        camera,
        width: window.innerWidth,
        height: window.innerHeight,
        groundReflector: null,
        intensity: ssrParams.reflectivity, // 设置反射强度
        maxDistance: ssrParams.maxDistance,
        thickness: ssrParams.thickness,
        quality: ssrParams.quality,
        resolution: ssrParams.resolution,
        blur: ssrParams.blur,
        kernelSize: ssrParams.kernelSize,
        iterations: ssrParams.iterations,
        blurAmount: ssrParams.blurAmount,
      });
      composer.insertPass(ssrPass, 1); // 确保SSRPass在RenderPass之后
    }
    // 更新SSRPass参数
    ssrPass.maxDistance = ssrParams.maxDistance;
    ssrPass.thickness = ssrParams.thickness;
    ssrPass.intensity = ssrParams.reflectivity; // 使用正确的属性名
    ssrPass.quality = ssrParams.quality;
    ssrPass.resolution.set(ssrParams.resolution, ssrParams.resolution);
    ssrPass.blur = ssrParams.blur;
    ssrPass.kernelSize = ssrParams.kernelSize;
    ssrPass.iterations = ssrParams.iterations;
    ssrPass.blurAmount = ssrParams.blurAmount;
    ssrPass.enabled = true;
  } else {
    if (ssrPass) {
      composer.removePass(ssrPass);
      ssrPass.dispose(); // 释放资源
      ssrPass = null;
    }
  }
});
gui.add(params, 'ssrDistance', 1, 10).name('SSR距离').onChange((value) => {
  ssrParams.maxDistance = value;
  if (ssrPass) ssrPass.maxDistance = value;
});
gui.add(params, 'ssrThickness', 0.1, 2).name('SSR厚度').onChange((value) => {
  ssrParams.thickness = value;
  if (ssrPass) ssrPass.thickness = value;
});
gui.add(params, 'ssrIterations', 1, 2).name('迭代次数').onChange((value) => { // 限制迭代次数到2
  ssrParams.iterations = value;
  if (ssrPass) ssrPass.iterations = value;
});
gui.add(params, 'ssrReflectivity', 0, 0.8).name('SSR反射强度').onChange((value) => { // 限制反射强度
  ssrParams.reflectivity = value;
  if (ssrPass) ssrPass.intensity = value; // 使用正确的属性名
});
gui.add(params, 'ssrQuality', 1, 2).name('SSR质量').onChange((value) => { // 限制SSR质量
  ssrParams.quality = value;
  if (ssrPass) ssrPass.quality = value;
});
gui.add(params, 'ssrResolution', 32, 128).name('SSR分辨率').onChange((value) => { // 降低分辨率
  ssrParams.resolution = value;
  if (ssrPass) ssrPass.resolution.set(value, value);
});
gui.add(params, 'ssrBlur').name('启用模糊').onChange((value) => {
  ssrParams.blur = value;
  if (ssrPass) ssrPass.blur = value;
});
gui.add(params, 'ssrKernelSize', 1, 2).name('模糊精度').onChange((value) => { // 降低模糊精度
  ssrParams.kernelSize = value;
  if (ssrPass) ssrPass.kernelSize = value;
});
gui.add(params, 'ssrBlurAmount', 0, 0.5).name('模糊强度').onChange((value) => { // 降低模糊强度
  ssrParams.blurAmount = value;
  if (ssrPass) ssrPass.blurAmount = value;
});

// 雾气控制
gui.add(params, 'fogEnabled').name('启用雾气').onChange((value) => {
  if (value) {
    scene.fog = new THREE.FogExp2(fogColor, fogDensity); // 启用雾气
  } else {
    scene.fog = null; // 禁用雾气
  }
});
gui.addColor(params, 'fogColor').name('雾气颜色').onChange((color) => {
  fogColor.set(color);
  if (scene.fog) {
    scene.fog.color.set(color); // 更新雾气颜色
  }
});
gui.add(params, 'fogDensity', 0.0005, 0.005).name('雾气浓度').onChange((value) => {
  fogDensity = value;
  if (scene.fog) {
    scene.fog.density = value; // 更新雾气浓度
  }
});

// 启动动画循环
animate();
